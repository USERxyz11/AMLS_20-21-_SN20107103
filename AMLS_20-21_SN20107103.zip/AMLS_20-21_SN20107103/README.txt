In theory, no package is required to be installed.

The format of the csv file is best as shown below:
A:
,gender,smiling,img_name
0,-1,-1,0.jpg
1,-1,1,1.jpg
2,1,1,2.jpg

B:
,eye_color,face_shape,file_name
0,2,1,0.png
1,1,4,1.png
2,0,2,2.png
3,0,2,3.png
The filename or img_name must be placed in the last column and separated by commas.