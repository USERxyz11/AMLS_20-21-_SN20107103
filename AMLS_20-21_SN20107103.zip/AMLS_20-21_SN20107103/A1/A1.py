
import numpy as np
from sklearn.metrics import classification_report,accuracy_score
from sklearn import svm
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn import tree
from sklearn.model_selection import train_test_split
import xgboost
from numpy import loadtxt
from xgboost import XGBClassifier 
import os
import numpy as np
from keras.preprocessing import image
import cv2
import dlib
from pathlib import Path
from PIL import Image
from sklearn.decomposition import PCA
from sklearn.model_selection import cross_val_score,KFold
from matplotlib import pyplot
from sklearn.model_selection import GridSearchCV


global basedir, image_paths
basedir = './Datasets/celeba'
images_dir = os.path.join(basedir,'img')
labels_filename = 'labels.csv'
basedir_test = './Datasets/celeba_test'
images_test_dir = os.path.join(basedir_test,'img')
img_size=70


def extract_features_labels(img_size):
    """
    This funtion extracts the features for all images in the folder 'dataset/celeba'.
    It also extracts the gender label for each image.
    :return:
        landmark_features:  an array containing 4900 points for each image in which a face was detected
        gender_labels:      an array containing the gender label (male=1 and female=-1) for each image 
    """
    image_paths = [os.path.join(images_dir, l) for l in os.listdir(images_dir)]    
    labels_file = open(os.path.join(basedir, labels_filename), 'r')
    lines = labels_file.readlines()
    gender_labels = {line.split(',')[0] : int(line.split(',')[1]) for line in lines[1:]}
    labels_file.close()    
    if os.path.isdir(images_dir):
        all_features = []
        all_labels = []
        for img_path in image_paths:
            file_name=Path(img_path).stem           
            img = cv2.imread(img_path)
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            res=cv2.resize(gray,(img_size,img_size),interpolation=cv2.INTER_CUBIC)
            features=res.reshape(-1)
            all_features.append(features)               
            all_labels.append(gender_labels[file_name])
          
    landmark_features = np.asarray(all_features,'int64')    
    gender_labels =np.asarray(all_labels,'int64') 
    return landmark_features, gender_labels

def extract_test_features_labels(img_size):
    """
    This funtion extracts the features for all images in the folder 'dataset/celeba_test'.
    It also extracts the gender label for each image.
    :return:
        landmark_features:  an array containing 4900 points for each image in which a face was detected
        gender_labels:      an array containing the gender label (male=1 and female=-1) for each image 
    """
    image_paths = [os.path.join(images_test_dir, l) for l in os.listdir(images_test_dir)]    
    labels_file = open(os.path.join(basedir_test, labels_filename), 'r')
    lines = labels_file.readlines()
    gender_labels = {line.split(',')[0] : int(line.split(',')[1]) for line in lines[1:]}
    labels_file.close()
       
    if os.path.isdir(images_test_dir):
        all_features = []
        all_labels = []
        for img_path in image_paths:           
            file_name=Path(img_path).stem            
            img = cv2.imread(img_path)
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            res=cv2.resize(gray,(img_size,img_size),interpolation=cv2.INTER_CUBIC)
            features=res.reshape(-1)       
            all_features.append(features)               
            all_labels.append(gender_labels[file_name])
          
    landmark_features = np.asarray(all_features,'int64')
    gender_labels =np.asarray(all_labels,'int64') 
    return landmark_features, gender_labels

def get_data(img_size):
    """
    Convert the extracted data into data conforming to the training format
    """
    X, y = extract_features_labels(img_size)    
    Y = np.array([y]).T    
    X_test,y_test=extract_test_features_labels(img_size)
    Y_test = np.array([y_test]).T
    tr_X = X
    tr_Y = Y
    te_X = X_test
    te_Y = Y_test
    return tr_X, tr_Y,te_X, te_Y


def best_params():
    """
    Use GridSearchCV for parameter tuning, and manually modify the obtained optimal parameters in other_params
    """
    tr_X, tr_Y,te_X, te_Y=get_data(img_size)
    cv_params = {'n_estimators':[700,900]}
    other_params = {
            
            
            'learning_rate':0.07,
            'n_estimators':700, 
            'max_depth':6, 
            'min_child_weight':1, 
            'max_delta_step':0,
            'subsample':1,
            'gamma':0.2, 
            'colsamplebylevel':1,
            'colsample_bytree':0.2, 
            'reg_lambda':1,
            'reg_alpha':0
            
            }   
    model = XGBClassifier(**other_params)
    optimized_XGB= GridSearchCV(estimator=model, 
                                 param_grid=cv_params, 
                                 cv=2, 
                                 n_jobs=-1)
    optimized_XGB.fit(tr_X, tr_Y)
    print('The best value of the parameter：{0}'.format(optimized_XGB.best_params_))
    print('Best model score:{0}'.format(optimized_XGB.best_score_))



def img_xgb():
    """
    Use KFold for k-fold cross validation and XGBoost for training
    """
    tr_X, tr_Y,te_X, te_Y=get_data(img_size)
    kf = KFold(n_splits=5)# n_splits=k
    for train_index, test_index in kf.split(tr_X):
        print('train:%s, valid:%s' % (train_index, test_index))
        xgb_model = XGBClassifier()
        xgb_model.fit(tr_X[train_index], tr_Y[train_index],eval_set=[(tr_X[test_index],tr_Y[test_index])])
        # eval_set is the validation set
    y_pred = xgb_model.predict(te_X)
    accuracy = accuracy_score(te_Y, y_pred)
    print("XGBoost Accuracy: %.2f%%" % (accuracy * 100.0))
    
    
def XGB_loss():
    """
    Record the evaluation function and graph to analyze the training convergence
    """
    tr_X, tr_Y,te_X, te_Y=get_data(img_size)
    train_error=[]
    eval_error=[]
    train_logloss=[]
    eval_logloss=[]
    train_error1=[]
    eval_error1=[]
    train_logloss1=[]
    eval_logloss1=[]
    kf = KFold(n_splits=5)
    for train_index, test_index in kf.split(tr_X):
        print('train:%s, valid:%s' % (train_index, test_index))
        xgb_model = XGBClassifier().fit(tr_X[train_index],tr_Y[train_index], eval_metric=["error", "logloss"],eval_set=[(tr_X[train_index], tr_Y[train_index]),(tr_X[test_index],tr_Y[test_index])])
        results = xgb_model.evals_result()#evals_result() records all records of the evaluation function
        train_error.append(results['validation_0']['error'])
        eval_error.append(results['validation_1']['error'])
        train_logloss.append(results['validation_0']['logloss'])
        eval_logloss.append(results['validation_1']['logloss'])
    
    # Early-stop
    kf = KFold(n_splits=5)
    for train_index, test_index in kf.split(tr_X):
        print('train:%s, valid:%s' % (train_index, test_index))
        xgb_model1 = XGBClassifier().fit(tr_X[train_index],tr_Y[train_index],early_stopping_rounds=10, eval_metric=["error", "logloss"],eval_set=[(tr_X[train_index], tr_Y[train_index]),(tr_X[test_index],tr_Y[test_index])])
        #Early stop is triggered after the convergence continues for the early_stopping_rounds epochs
        results1 = xgb_model1.evals_result()
        train_error1.append(results1['validation_0']['error'])
        eval_error1.append(results1['validation_1']['error'])
        train_logloss1.append(results1['validation_0']['logloss'])
        eval_logloss1.append(results1['validation_1']['logloss'])

    #
    y_pred = xgb_model.predict(te_X)
    accuracy = accuracy_score(te_Y, y_pred)
    print("XGBoost Accuracy: %.2f%%" % (accuracy * 100.0))
    
    epochs = len(train_error[0])
    x_axis = range(0, epochs)
    # plot train error
    fig, ax = pyplot.subplots()
    ax.plot(x_axis, train_error[0], label='Train1')
    ax.plot(x_axis, train_error[1], label='Train2')
    ax.plot(x_axis, train_error[2], label='Train3')
    ax.plot(x_axis, train_error[3], label='Train4')
    ax.plot(x_axis, train_error[4], label='Train5')
    ax.legend()
    pyplot.xlabel('ephoch')
    pyplot.ylabel('error')
    pyplot.title('XGBoost train error')   
    plt.savefig('XGBoost train error.jpg')
    pyplot.show()
    
    epochs = len(eval_error[0])
    x_axis = range(0, epochs)
    # plot evaluation error
    fig, ax = pyplot.subplots()
    ax.plot(x_axis, eval_error[0], label='eval1')
    ax.plot(x_axis, eval_error[1], label='eval2')
    ax.plot(x_axis, eval_error[2], label='eval3')
    ax.plot(x_axis, eval_error[3], label='eval4')
    ax.plot(x_axis, eval_error[4], label='eval5')
    ax.legend()
    pyplot.xlabel('ephoch')
    pyplot.ylabel('error')
    pyplot.title('XGBoost eval error')
    plt.savefig('XGBoost eval error.jpg')
    pyplot.show()
    
    
    epochs = len(train_logloss[0])
    x_axis = range(0, epochs)
    # plot train logloss
    fig, ax = pyplot.subplots()
    ax.plot(x_axis, train_logloss[0], label='train1')
    ax.plot(x_axis, train_logloss[1], label='train2')
    ax.plot(x_axis, train_logloss[2], label='train3')
    ax.plot(x_axis, train_logloss[3], label='train4')
    ax.plot(x_axis, train_logloss[4], label='train5')
    ax.legend()
    pyplot.xlabel('ephoch')
    pyplot.ylabel('logloss')
    pyplot.title('XGBoost train logloss')    
    plt.savefig('XGBoost train logloss.jpg')
    pyplot.show()
    
    epochs = len(eval_logloss[0])
    x_axis = range(0, epochs)
    # plot evalution logloss
    fig, ax = pyplot.subplots()
    ax.plot(x_axis, eval_logloss[0], label='eval1')
    ax.plot(x_axis, eval_logloss[1], label='eval2')
    ax.plot(x_axis, eval_logloss[2], label='eval3')
    ax.plot(x_axis, eval_logloss[3], label='eval4')
    ax.plot(x_axis, eval_logloss[4], label='eval5')
    ax.legend()
    pyplot.xlabel('ephoch')
    pyplot.ylabel('logloss')
    pyplot.title('XGBoost eval logloss')
    plt.savefig('XGBoost eval logloss.jpg')
    pyplot.show()
    
    
     # Early-stop
    y_pred1 = xgb_model1.predict(te_X)
    accuracy = accuracy_score(te_Y, y_pred1)
    print("Early-stop XGBoost Accuracy: %.2f%%" % (accuracy * 100.0))   
    
    # plot error
    epochs = len(eval_error1[4])
    x_axis = range(0, epochs)
    fig, ax = pyplot.subplots()
    ax.plot(x_axis, train_error1[4], label='train')
    ax.plot(x_axis, eval_error1[4], label='eval')
    ax.legend()
    pyplot.xlabel('ephoch')
    pyplot.ylabel('error')
    pyplot.title('Early-stop XGBoost error')    
    plt.savefig('Early-stop XGBoost error.jpg')
    pyplot.show()
    
    # plot log loss
    epochs = len(eval_logloss1[4])
    x_axis = range(0, epochs)    
    fig, ax = pyplot.subplots()
    ax.plot(x_axis, train_logloss1[4], label='train')
    ax.plot(x_axis, eval_logloss1[4], label='eval')
    ax.legend()
    pyplot.xlabel('ephoch')
    pyplot.ylabel('logloss')
    pyplot.title('Early-stop XGBoost logloss')
    plt.savefig('Early-stop XGBoost logloss.jpg')
    pyplot.show()





def get_score():
    """
    Use XGBoost to train and get training error, verification error and prediction error
    """
    tr_X, tr_Y, te_X, te_Y= get_data(img_size)
    train_accuracy=[]
    eval_accuracy=[]
    kf = KFold(n_splits=4)#Define k value
    xgb_model = XGBClassifier(min_child_weight=0.09,max_depth=5,n_estimators=500,gamma=0)
    for train_index, test_index in kf.split(tr_X):#Use k-fold cross validation
            print('train:%s, valid:%s' % (train_index, test_index))           
            xgb_model.fit(tr_X[train_index], tr_Y[train_index],eval_set=[(tr_X[test_index],tr_Y[test_index])],verbose=False)
            train_accuracy.append(accuracy_score(tr_Y[train_index], xgb_model.predict(tr_X[train_index])))
            eval_accuracy.append(accuracy_score(tr_Y[test_index], xgb_model.predict(tr_X[test_index])))
    
    y_pred = xgb_model.predict(te_X)
    accuracy = accuracy_score(te_Y, y_pred)
    #print("XGBoost Accuracy: %.2f%%" % (accuracy * 100.0))
    #print("XGBoost train Accuracy: %.2f%%" % ((np.mean(train_accuracy)) * 100.0))
    #print("XGBoost eval Accuracy: %.2f%%" % ((np.mean(eval_accuracy)) * 100.0))
    acc=accuracy * 100.0
    train_acc=(np.mean(train_accuracy)) * 100.0
    eval_train=(np.mean(eval_accuracy)) * 100.0
    return acc,train_acc,eval_train

def compare_size():
    """
    Compare how compression size affects accuracy
    """
    result=[]
    for i in range(10,150,10):#size from 10*10 to 140*140
        tr_X, tr_Y,te_X, te_Y=get_data(i)
        kf = KFold(n_splits=4)
        model = XGBClassifier()
        for train_index, test_index in kf.split(tr_X):          
            model.fit(tr_X[train_index], tr_Y[train_index],eval_set=[(tr_X[test_index],tr_Y[test_index])])
        y_pred = model.predict(te_X)
        accuracy = accuracy_score(te_Y, y_pred)
        result.append(accuracy * 100.0)
        print(" Accuracy: %.2f%%" % (accuracy * 100.0))
    #plot
    epochs = len(result)
    x_axis = range(10, (epochs+1)*10,10)
    fig, ax = pyplot.subplots()
    ax.plot(x_axis, result, label='size')    
    ax.legend()
    pyplot.xlabel('size')
    pyplot.ylabel('Accuracy')
    pyplot.title('A1 reshape size affect Accuracy')    
    plt.savefig('A1 reshape size affect Accuracy.jpg')
    pyplot.show()



def eval_size():
    """
    Use different values of k to influence the size of the validation set to explore the impact on accuracy
    Validation set size = total data size/k
    """
    tr_X, tr_Y,te_X, te_Y=get_data(img_size)
    result=[]
    for i in range(2,11,1):#k increase from 2 to 10
        model = XGBClassifier()
        kf = KFold(n_splits=i)
        for train_index, test_index in kf.split(tr_X):           
            model.fit(tr_X[train_index], tr_Y[train_index],eval_set=[(tr_X[test_index],tr_Y[test_index])])
        y_pred = model.predict(te_X)
        accuracy = accuracy_score(te_Y, y_pred)
        result.append(accuracy * 100.0)
        print(" Accuracy: %.2f%%" % (accuracy * 100.0))
    #plot
    epochs = len(result)
    x_axis = range(2, (epochs+2),1)
    fig, ax = pyplot.subplots()
    ax.plot(x_axis, result, label='K size')    
    ax.legend()
    pyplot.xlabel('K size')
    pyplot.ylabel('Accuracy')
    pyplot.title('A1 eval size affect Accuracy')    
    plt.savefig('A1 eval size affect Accuracy.jpg')
    pyplot.show()