
from A1 import A1 as model_A1
from A2 import A2 as model_A2
from B1 import B1 as model_B1
from B2 import B2 as model_B2

# ======================================================================================================================
# Data preprocessing

# ======================================================================================================================
# Task A1
acc_A1,acc_A1_train,acc_A1_val=model_A1.get_score()

#Output training convergence graph, evaluation criteria are error and logloss
#model_A1.XGB_loss()

#Output about the impact of image size on accuracy
#model_A1.compare_size()

#Output about the impact of k value (validation set size) on accuracy
#model_A1.eval_size()

#The above three functions are time-consuming, and the results are reflected in the report
#A2, B1, B2 also have these three functions
# ======================================================================================================================
# Task A2
acc_A2,acc_A2_train,acc_A2_val=model_A2.get_score()

# ======================================================================================================================
# Task B1
acc_B1,acc_B1_train,acc_B1_val=model_B1.get_score()


# ======================================================================================================================
# Task B2
acc_B2,acc_B2_train,acc_B2_val=model_B2.get_score()

# ======================================================================================================================
## Print out your results with following format:

##The first is prediction accuracy, the second is training accuracy, and the third is verification accuracy

print('TA1:{},{},{};TA2:{},{},{};TB1:{},{},{};TB2:{},{},{};'.format(acc_A1,acc_A1_train, acc_A1_val,
                                                        acc_A2,acc_A2_train,acc_A2_val,
                                                        acc_B1,acc_B1_train,acc_B1_val,
                                                        acc_B2,acc_B2_train,acc_B2_val))
